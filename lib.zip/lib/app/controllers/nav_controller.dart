import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../pages/about_page.dart';
import '../pages/home_page.dart';
import '../pages/contact_page.dart';

class NavController extends GetxController {
  var currentRoute = '/home'.obs;

  void navigateTo(String routeName){
    if(currentRoute.value == routeName) {
      return;
    }
    currentRoute.value = routeName;

    Get.offAll(
      () => _getPageForRoute(routeName),
      transition: Transition.fadeIn,
      duration: const Duration(milliseconds: 200),
    );
  }

  Widget _getPageForRoute(String routeName) {
    switch (routeName) {
      case '/home':
        return HomePage();
      case '/about':
        return AboutPage();
      case '/contact':
        return ContactPage();
      default:
        return HomePage();
    }
  }
}